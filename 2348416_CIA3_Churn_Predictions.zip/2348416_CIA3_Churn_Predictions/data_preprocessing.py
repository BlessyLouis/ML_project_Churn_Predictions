import streamlit as st
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.model_selection import train_test_split

# Load data function
@st.cache(allow_output_mutation=True)
def load_data(file_path):
    data = pd.read_csv(file_path)
    return data

# Handle missing values function
def handle_missing_values(data):
    numeric_columns = data.select_dtypes(include=np.number).columns
    imputer = SimpleImputer(strategy='mean')
    data_filled = data.copy()
    for col in numeric_columns:
        data_filled[col] = imputer.fit_transform(data[[col]])
    return data_filled

# Encode categorical variables function
def encode_categorical_variables(data):
    encoder = OneHotEncoder()
    encoded_data = encoder.fit_transform(data)
    return encoded_data

# Feature scaling function
def feature_scaling(data):
    numeric_columns = data.select_dtypes(include=np.number).columns
    scaler = StandardScaler()
    scaled_data = data.copy()
    scaled_data[numeric_columns] = scaler.fit_transform(data[numeric_columns])
    return scaled_data

