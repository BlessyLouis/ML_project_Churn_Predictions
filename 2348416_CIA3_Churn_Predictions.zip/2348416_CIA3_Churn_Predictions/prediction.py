import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
import streamlit as st
# Load the model
@st.cache(allow_output_mutation=True)
def load_model(model_type, X_train, y_train):
    if model_type == 'Logistic Regression':
        model = train_logistic_regression(X_train, y_train)
    elif model_type == 'Random Forest':
        model = train_random_forest(X_train, y_train)
    return model

# Predict function
def predict(model, input_features):
    prediction = model.predict(input_features)
    return prediction
