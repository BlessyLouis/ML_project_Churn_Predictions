import streamlit as st
import matplotlib.pyplot as plt
import seaborn as sns

# Exploratory Data Analysis function
def visualize_distribution(data):
    st.header("Exploratory Data Analysis")
    # Calculate churn rate
    churn_rate = data['Exited'].mean() * 100  # Convert to percentage

    # Display overall churn rate
    st.markdown(f"<p style='font-size: 24px; font-weight: bold; color: red;'>Overall Churn Rate: {churn_rate:.2f}%</p>", unsafe_allow_html=True)
    st.subheader("Distribution of Gender")
    fig, ax = plt.subplots(figsize=(6, 6))
    data['Gender'].value_counts().plot.pie(autopct='%1.1f%%', startangle=140, colors=['skyblue', 'lightcoral'])
    st.pyplot(fig)

    st.subheader("Distribution of Exited")
    fig, ax = plt.subplots(figsize=(6, 6))
    data['Exited'].value_counts().plot.pie(autopct='%1.1f%%', startangle=140, colors=['lightgreen', 'lightcoral'])
    st.pyplot(fig)

    st.subheader("Distribution of HasCrCard")
    fig, ax = plt.subplots(figsize=(6, 6))
    data['HasCrCard'].value_counts().plot.pie(autopct='%1.1f%%', startangle=140, colors=['lightblue', 'orange'])
    st.pyplot(fig)

    st.subheader("Distribution of IsActiveMember")
    fig, ax = plt.subplots(figsize=(6, 6))
    data['IsActiveMember'].value_counts().plot.pie(autopct='%1.1f%%', startangle=140, colors=['lightpink', 'lightgreen'])
    st.pyplot(fig)

    st.subheader("Distribution of Geography")
    fig, ax = plt.subplots(figsize=(8, 6))
    sns.countplot(x='Geography', data=data, palette='Set2')
    st.pyplot(fig)

    st.subheader("Distribution of Balance")
    fig, ax = plt.subplots(figsize=(8, 6))
    sns.histplot(data['Balance'], kde=True, color='skyblue')
    st.pyplot(fig)

    st.subheader("Distribution of Age")
    fig, ax = plt.subplots(figsize=(8, 6))
    sns.histplot(data['Age'], kde=True, color='lightcoral')
    st.pyplot(fig)

    st.subheader("Boxplot of EstimatedSalary")
    fig, ax = plt.subplots(figsize=(8, 6))
    sns.boxplot(data['EstimatedSalary'], color='lightgreen', ax=ax)
    st.pyplot(fig)

    st.subheader("Violin plot of CreditScore")
    fig, ax = plt.subplots(figsize=(8, 6))
    sns.violinplot(data['CreditScore'], color='lightcoral', ax=ax)
    st.pyplot(fig)
    
    st.subheader("Pairplot of All Features")
    sns.pairplot(data)
    st.pyplot()

