import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
import streamlit as st
import pandas as pd
import numpy as np
from data_preprocessing import load_data, handle_missing_values, feature_scaling
from visualization import visualize_distribution
from model_building import train_logistic_regression, train_random_forest, evaluate_model, preprocess_data,plot_confusion_matrix
from prediction import load_model, predict
# Title customization with thicker horizontal line
st.markdown(
    "<h1 style='text-align: center; font-weight: bold; margin-top: -50px;'>Customer Churn Analysis</h1>"
    "<hr style='border-width: 5px;'>",
    unsafe_allow_html=True
)






# Load the model
@st.cache(allow_output_mutation=True)
def load_model(model_type, X_train, y_train):
    if model_type == 'Logistic Regression':
        model = train_logistic_regression(X_train, y_train)
    elif model_type == 'Random Forest':
        model = train_random_forest(X_train, y_train)
    return model

# Predict function
def predict(model, input_features):
    prediction = model.predict(input_features)
    return prediction

# Main function
def main():
    # Add background color
    st.markdown(
        """
        <style>
        body {
            background-color: #ED9455; /* Specify background color */
        }
        </style>
        """,
        unsafe_allow_html=True
    )
    

    # Sidebar menu
    menu = ["Data Acquisition and Pre-processing", "Exploratory Data Analysis", "Model Building and Evaluation", "Customer Prediction"]
    choice = st.sidebar.selectbox("Menu", menu)

    # Data Acquisition and Pre-processing
    if choice == "Data Acquisition and Pre-processing":
        st.header("Data Acquisition and Pre-processing")
        file_path = st.file_uploader("Upload CSV file", type=["csv"])
        if file_path is not None:
            data = load_data(file_path)
            st.write("Preview of the dataset:")
            st.write(data.head())

            st.subheader("Handling Missing Values:")
            data = handle_missing_values(data)
            st.write("Preview after handling missing values:")
            st.write(data.head())

            st.subheader("Feature Scaling:")
            scaled_data = feature_scaling(data)
            st.write("Preview after feature scaling:")
            st.write(scaled_data)
            st.subheader("Structural Information:")
            st.write("Number of Rows:", data.shape[0])
            st.write("Number of Columns:", data.shape[1])
            st.write("Column Names:", data.columns.tolist())
            st.write("Data Types:")
            st.write(data.dtypes)
         

            st.subheader("Descriptive Statistics:")
            st.write(data.describe())

            st.subheader("Correlation Matrix:")
            data_encoded = pd.get_dummies(scaled_data)
            corr_matrix = data_encoded.corr()
            st.write(corr_matrix)

            st.subheader("Number of Null Values in Each Column:")
            st.write(data.isnull().sum())
    # Exploratory Data Analysis
    elif choice == "Exploratory Data Analysis":
        st.header("Exploratory Data Analysis")
        file_path = st.file_uploader("Upload CSV file", type=["csv"])
        if file_path is not None:
            data = load_data(file_path)
            visualize_distribution(data)

    # Model Building and Evaluation
    elif choice == "Model Building and Evaluation":
        st.header("Model Building and Evaluation")
        file_path = st.file_uploader("Upload CSV file", type=["csv"])
        if file_path is not None:
            data = load_data(file_path)
            X_train, X_test, y_train, y_test = preprocess_data(data)
            model_choice = st.radio("Choose Model:", ("Logistic Regression", "Random Forest"))

            if model_choice == "Logistic Regression":
                model = train_logistic_regression(X_train, y_train)
            else:
                model = train_random_forest(X_train, y_train)

            accuracy, precision, recall, f1, cm = evaluate_model(model, X_test, y_test)
            st.write(f"Accuracy: {accuracy:.2f}")
            st.write(f"Precision: {precision:.2f}")
            st.write(f"Recall: {recall:.2f}")
            st.write(f"F1 Score: {f1:.2f}")

            st.subheader("Confusion Matrix:")
            plot_confusion_matrix(cm)

    # Customer Prediction
    elif choice == "Customer Prediction":
        st.header("Customer Prediction")
        # Feature inputs and prediction section goes here

        # Load the model
        file_path = st.file_uploader("Upload CSV file", type=["csv"])
        if file_path is not None:
            data = load_data(file_path)
            X_train, X_test, y_train, y_test = preprocess_data(data)
            model_type = st.radio("Choose Model:", ("Logistic Regression", "Random Forest"))
            model = load_model(model_type, X_train, y_train)

            # Feature inputs and prediction section goes here
            credit_score = st.slider("Credit Score", min_value=300, max_value=850, value=500)
            tenure = st.slider("Tenure", min_value=0, max_value=20, value=5)
            balance = st.number_input("Balance", value=0)
            num_of_products = st.slider("Number of Products", min_value=1, max_value=4, value=2)
            has_cr_card = st.radio("Has Credit Card", options=["Yes", "No"])
            is_active_member = st.radio("Is Active Member", options=["Yes", "No"])
            estimated_salary = st.number_input("Estimated Salary", value=0)
            gender = st.radio("Gender", options=["Male", "Female"])  # Add gender input

            # Map categorical values to encoded values
            input_features = pd.DataFrame({
                'CreditScore': [credit_score],
                'Tenure': [tenure],
                'Balance': [balance],
                'NumOfProducts': [num_of_products],
                'HasCrCard': [1 if has_cr_card == "Yes" else 0],
                'IsActiveMember': [1 if is_active_member == "Yes" else 0],
                'EstimatedSalary': [estimated_salary],
                'Gender_Female': [1 if gender == "Female" else 0],
                'Gender_Male': [1 if gender == "Male" else 0]  # Assuming 'gender' is a variable in your UI
            })

            # Make prediction
            prediction = predict(model, input_features)

            # Display prediction result
            st.subheader("Prediction Result")
            if prediction[0] == 0:
                st.markdown("<p style='color:green'>The customer is not likely to churn.</p>", unsafe_allow_html=True)
            else:
                st.markdown("<p style='color:red'>The customer is likely to churn.</p>", unsafe_allow_html=True)

            # Display prediction result using a semi-circle speedometer
            st.subheader("Prediction Result")
            fig, ax = plt.subplots(figsize=(6, 5))
            if prediction[0] == 0:
                color = 'green'
            else:
                color = 'red'
            ax.add_patch(mpatches.Wedge((0.5, 0), 0.4, 0, 180, color=color, alpha=0.5))
            ax.arrow(0.5, 0.4, 0, -0.3, width=0.03, head_width=0.08, head_length=0.08, fc=color, ec=color)
            ax.set_xlim(0, 1)
            ax.set_ylim(0, 1)
            ax.axis('off')
            st.pyplot(fig)
            
if __name__ == "__main__":
    main()
